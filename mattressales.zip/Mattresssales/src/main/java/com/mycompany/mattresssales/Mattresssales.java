/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mattresssales;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Scanner;
/**
 *
 * @author kiaraadams
 */
public class Mattresssales {

    public static void main(String[] args) {
        // Product Names
        String[]products = {"Cozy night Monarch mattress","Restonic Barbados mattress", "Sealy Phuket mattress",
    };
        //Sales date for 3 months
        int [][] sales = {
            {25,18, 20},//Cozy night Monarch mattress
            {15, 10, 12},// Restonic Barbados mattress
            {18,15,20},// Sealy Phuket mattress
        };
        int totalProductsSold = 0;
        int[] totalSalesPerProduct = new int [Product.length];
        // Calculate tottal sales 
        for ( int j =0; j < 3; j++){
            totalSalesPerProduct[i] ==Sales[i][j];
            
            }
        totalProductsSold+=totalSalesPerProduct[i];
        }
    //Calculates average popular product
    int maxIndex = 0;
    for(totalSalesPerProduct[i]> totalSalesPerProduct[maxIndex]){
    maxIndex = i;
}
    //Display report
    System.out.println("=======SALES REPORT=======");
    System.out.println("Total Products Sales: " = totalProductsSold);
    System.out.println("Averge products Sold per Product: %.2f%n",
            averageSales);
    system.out.println("Most Popular product : "+ products [manIndex]
    + "("+totalSalesperproduct[maxIndex]+ "sales");
    
    //Top 3 best sellers
    System.out.print("\nTop 3 Best-Selling Products:");
    
    for (int rank = 1; rank <=3, rank++){
    int highestIndex = - 1;
    for (int i =0; i TotalaSalesperproduct.length;i++){
    if (highestindex == -1 ||
            totalSalesPerProduct[i]>
            totalSalesperproduct[highestIndex]) {
    highestIndex = i
}
    System.out.println(rank + ".  "+ totalSalesPerProduct [highestIndex] + "sales");
    
    //Used
    totalSalesPerProduct[HighestIndex] = - 1;
    
}
}
   
