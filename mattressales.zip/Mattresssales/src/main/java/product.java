/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author kiaraadams
 */
public class product {
    public int GetTotalProductsSold(){
        return 0;
    }
    public double GetAverarageproductSold(){
        return 0.0;
    }  
    public String GetMostPopulatProduct(){
        return"";
        
    }
}
